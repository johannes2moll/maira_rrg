from structeval import StructEval
from structeval import StructBert